<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User Input Array - Traveling</title>
</head>
<body>
    <h2>How are you traveling?</h2>


    <?php
//If form not submitted, display form.  
if (!isset($_POST['submit'])){
$travel=array(
  "Automobile",
  "Jet",
  "Ferry",
  "Subway"
);
 
?>
 
<p>Travel takes many forms, whether across town, across the country, or
 around the world. Here is a list of some common modes of transportation:</p>
<ul>
 
<?php
foreach ($travel as $t){
  echo "<li>$t</li>\n"; 
}
?>
 
</ul>
<form method="post" action="AddUserInput.php">
<p>Please add your favorite, local, or even imaginary modes of travel 
to the list, separated by commas:</p>
<input type="text" name="added" size="80" />
<p />
 
<?php
//Send current travel array as hidden form data.
foreach ($travel as $t){
  echo "<input type=\"hidden\" name=\"travel[]\" value=\"$t\" />\n";
}
?>
 
<input type="submit" name="submit" value="Go" />
</form>
 
<?php
//If form submitted, process input.
}else{
//Retrieve established travel array.
$travel=($_POST['travel']);
//Convert user input string into an array.
$added=explode(',',$_POST['added']);
 
//Add to the established array.
array_splice($travel, count($travel), 0, $added);
//This could also be written $travel=array_merge($travel, $added);
 
//Return the new list to the user.
echo "<p>Here is the list with your additions:</p>\n<ul>\n";
foreach($travel as $t){
  //The trim functions deletes extra spaces the user may have entered.
  echo "<li>".trim($t)."</li>\n";  
}
echo"</ul>";  
 
?>
<p>Add more?</p>
<form method="post" action="AddUserInput.php">
<input type="text" name="added" size="80" />
<p />
<?php
//Send current travel array as hidden form data.
foreach ($travel as $t){
  echo "<input type=\"hidden\" name=\"travel[]\" value=\"$t\" />\n";
}
?>
<input type="submit" name="submit" value="Go" />
</form>
<?php
}
?>

</body>
</html>