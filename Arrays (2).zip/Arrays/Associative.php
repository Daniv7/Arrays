<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Associative Array - Largest cities again</title>
</head>
<body>
    
<?php
  //Create associative array with countries as keys, cities as values.
  $cities=array(
    "Japan" => "Tokyo",
    "Mexico" => "Mexico City",
    "USA" => "New York City",
    "India" => "Mumbai",
    "Korea" => "Seoul",
    "China" => "Shanghai",
    "Nigeria" => "Lagos",
    "Argentina" => "Buenos Aires",
    "Egypt" => "Cairo",
    "UK" => "London"
  );
  //If form not submitted, display form.
  if(!isset($_POST['submit'])){
?>
 
<form method="post" action="Associative.php">
<p>Please choose a city:</p>
<select name="city">
 
<?php
  //Use array to create options for select field.
  //Be sure to escape the quotes and include a line feed. 
  foreach($cities as $c){
    echo "<option value=\"$c\">$c</option>\n";
  }
?>
 
</select> <p />
<input type="submit" name="submit" value="Go">
</form>
 
<?php
  //If form submitted, process input.
  }else{
    //Retrieve user response.
    $city=$_POST['city'];
    //Find corresponding key in associative array.
    $country=array_search($city, $cities);
    //Send the data back to the user.
    echo "<p>$city is in $country.</p>" ;
 
  }
?>

</body>
</html>